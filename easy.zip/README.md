# Welcome to Easy Trivia
# Authour: James Campbell
# Based on a trivia question generator api called:
# Open Trivia Database
# Source: https://opentdb.com/
## Description:
## An easy way to generate trivia questions, whether for personal studying use, an easy way to host a trivia event, or just pass the time with friends. 
## This application uses session cookies to store an api token so that a user does not ever recieve the same question, within reason.
